import PromiseKit

protocol AnalyticsPresenterToInteractorProtocol: AnyObject {
  func loadEvents(with period: Period?)
}


final class AnalyticsInteractor {
  weak var presenter: AnalyticsInteractorToPresenterProtocol?
  var eventService: AnyCRUDService<EventEntity>!
  var eventsObservationService: AnyLocalDatabaseObservationService<EventEntity>!
    
  var insulinStatisticService: AnyCRUDService<InsulinStaticticType>!
  var insulinStatisticObservationService: AnyLocalDatabaseObservationService<InsulinStaticticType>!
  
  var profileSettingsService: AnyCRUDService<ProfileSettingsEntity>!
  var profileSettingsObservationService: AnyLocalDatabaseObservationService<ProfileSettingsEntity>?
  
  var accountSettingsService: AnyCRUDService<AccountSettingsEntity>!
  var accountSettingsObservationService: AnyLocalDatabaseObservationService<AccountSettingsEntity>!
    
  var insulinMedicamentsService: AnyCRUDService<InsulinMedicaments>!
  var insulinMedicamentsObservationService: AnyLocalDatabaseObservationService<InsulinMedicaments>!
    
  private var insulinStaticTypes = [InsulinStaticticType]()
  private var insulinTypes = [InsulinType]()
  private var profileSettings: ProfileSettingsEntity?
  private var events = [EventEntity]()
  private var selectedPeriod: Period = .days7
}


extension AnalyticsInteractor: AnalyticsPresenterToInteractorProtocol {
  func loadEvents(with period: Period?) {
    var eventListFetchOption = EventEntity.EventsFetchOption.combined(options: [
      .inDateRange(period?.datesRange ?? selectedPeriod.datesRange),
      .list(type: [.glucose, .activity, .bread, .insulin])])
    
    if let period = period {
      if case Period.day(let date) = period {
        eventListFetchOption = EventEntity.EventsFetchOption.combined(options: [
          .allDay(forDate: date),
          .list(type: [.glucose, .activity, .bread, .insulin])])
      } else {
        selectedPeriod = period
      }
    }
    
    firstly {
        when(fulfilled:
                eventService.getList(option: eventListFetchOption),
                profileSettingsService.getList(option: .all),
                insulinStatisticService.getList(option: .all),
                insulinMedicamentsService.getList(option: .all)
        )
    }.done {
      self.events = $0.0
      self.profileSettings = $0.1.first
      self.insulinStaticTypes = $0.2
        
        var typesDict = [Int: InsulinType]()
        $0.3.forEach {
            guard let type = $0.insulinType else { return }
            typesDict[type.id] = type
        }
        self.insulinTypes = Array(typesDict.values)
        
      self.presenter?.onInteractorSuccessEventsFetch(events: self.events,
                                                     forPeriod: period ?? self.selectedPeriod,
                                                     profileSettings: self.profileSettings,
                                                     statisticsTypes: self.insulinStaticTypes,
                                                     insulinTypes: self.insulinTypes)
      self.startObservationServices(option: eventListFetchOption)
    }.catch {
      self.presenter?.onInteractorError($0)
    }
  }
  
  func startObservationServices(option: EventEntity.ListFetchOption) {
    startEventsObservationService(option: option)
    startProfileSettingsObservationService()
    startAccountSettingObservation()
    startMedicamentsObservation()
  }
}

private extension AnalyticsInteractor {
  func startEventsObservationService(option: EventEntity.ListFetchOption) {
    guard let eventsObservationService = eventsObservationService else { return }
    eventsObservationService.observe(option: option) { [weak self] updates in
      guard let self = self else { return }
      self.events = updates.fullList
      self.presenter?.onInteractorSuccessEventsFetch(events: self.events,
                                                     forPeriod: self.selectedPeriod,
                                                     profileSettings: self.profileSettings,
                                                     statisticsTypes: self.insulinStaticTypes,
                                                     insulinTypes: self.insulinTypes)
    }
  }
  func startProfileSettingsObservationService() {
    guard let profileSettingsObservationService = profileSettingsObservationService else { return }
    profileSettingsObservationService.observe(option: .all) { [weak self] updates in
      guard let self = self else { return }
      self.profileSettings = updates.fullList.first
      self.presenter?.onInteractorSuccessEventsFetch(events: self.events,
                                                     forPeriod: self.selectedPeriod,
                                                     profileSettings: self.profileSettings,
                                                     statisticsTypes: self.insulinStaticTypes,
                                                     insulinTypes: self.insulinTypes)
    }
  }
    
  func startAccountSettingObservation() {
    accountSettingsObservationService.observe(option: .all) { [weak self] updates in
      guard let self = self else { return }
        self.loadEvents(with: self.selectedPeriod)
      }
    }
    
    func startInsulinStatisticObservation() {
        insulinStatisticObservationService.observe(option: .all) { [weak self] updates in
            guard let self = self else { return }
            self.insulinStaticTypes = updates.fullList
            self.presenter?.onInteractorSuccessEventsFetch(events: self.events,
                                                           forPeriod: self.selectedPeriod,
                                                           profileSettings: self.profileSettings,
                                                           statisticsTypes: self.insulinStaticTypes,
                                                           insulinTypes: self.insulinTypes)
        }
    }
    
    func startMedicamentsObservation() {
        insulinMedicamentsObservationService.observe(option: .all) { [weak self] updates in
            guard let self = self else { return }
            var typesDict = [Int: InsulinType]()
            updates.fullList.forEach {
                guard let type = $0.insulinType else { return }
                typesDict[type.id] = type
            }
            self.insulinTypes = Array(typesDict.values)
            self.presenter?.onInteractorSuccessEventsFetch(events: self.events,
                                                           forPeriod: self.selectedPeriod,
                                                           profileSettings: self.profileSettings,
                                                           statisticsTypes: self.insulinStaticTypes,
                                                           insulinTypes: self.insulinTypes)
        }
    }
}
