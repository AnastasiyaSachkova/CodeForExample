import Foundation

final class AnalyticsModuleFactory: BaseModuleFactoryProtocol {
  static func create() -> (input: AnalyticsModuleInput, viewable: ModuleViewable, router: BaseRouterProtocol) {
    let view = AnalyticsViewController()
    let presenter = AnalyticsPresenter()
    let interactor = AnalyticsInteractor()
    let router = AnalyticsRouter()
    
    let glucosePointsChartModule = AnyModuleFactory().create(GlucosePointsModuleFactory.self)
    let glucoseBarsChartModule = AnyModuleFactory().create(GlucoseBarsModuleFactory.self)
    glucoseBarsChartModule.input.moduleOutput = presenter
    
    view.presenter = presenter
    view.glucosePointsChartVC = glucosePointsChartModule.viewable.viewController
    view.glucoseBarsChartVC = glucoseBarsChartModule.viewable.viewController
    
    presenter.view = view
    presenter.interactor = interactor
    presenter.router = router
    
    presenter.glucoseBarsModule = glucoseBarsChartModule.input
    presenter.glucosePointsModule = glucosePointsChartModule.input
    
    let serviceLocator: ServiceLocatorProtocol = ServiceLocator.shared
    
    let eventService = serviceLocator.getCRUDLocalService(EventEntity.self)
    let profileService = serviceLocator.getCRUDLocalService(ProfileSettingsEntity.self)
    let eventsObservationService = serviceLocator.getLocalDatabaseObservationService(EventEntity.self)
    let profileSettingsObservationService = serviceLocator.getLocalDatabaseObservationService(ProfileSettingsEntity.self)
    let accountSettingsObservationService = serviceLocator.getLocalDatabaseObservationService(AccountSettingsEntity.self)
    let accountSettingsService = serviceLocator.getCRUDLocalService(AccountSettingsEntity.self)
    let insulinStatisticService = serviceLocator.getCRUDLocalService(InsulinStaticticType.self)
    let insulinStatisticObservationService = serviceLocator.getLocalDatabaseObservationService(InsulinStaticticType.self)
    let medicamentsService = serviceLocator.getCRUDLocalService(InsulinMedicaments.self)
    let medicamentsObservation = serviceLocator.getLocalDatabaseObservationService(InsulinMedicaments.self)
    
    interactor.presenter = presenter
    interactor.eventService = eventService
    interactor.eventsObservationService = eventsObservationService
    interactor.accountSettingsService = accountSettingsService
    interactor.accountSettingsObservationService = accountSettingsObservationService
    interactor.insulinStatisticService = insulinStatisticService
    interactor.insulinStatisticObservationService = insulinStatisticObservationService
    interactor.insulinMedicamentsService = medicamentsService
    interactor.insulinMedicamentsObservationService = medicamentsObservation
    
    interactor.profileSettingsService = profileService
    interactor.profileSettingsObservationService = profileSettingsObservationService
    
    router.view = view

    return (presenter, view, router)
  }
}
