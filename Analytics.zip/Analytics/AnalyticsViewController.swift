import Foundation
import UIKit

enum AnalyticsViewEvent {
  case onPeriodChanged(Period)
  case onButtonRightNavigationTap
  case onDayChanged
}

protocol AnalyticsPresenterToViewProtocol: Loadable {
  func setupInitialState()
  func updateAnalytics(_ analyticsDataViewItem: AnalyticsDataViewItem)
}


final class AnalyticsViewController: BaseViewController<AnalyticsView> {
  var glucoseBarsChartVC: UIViewController?
  var glucosePointsChartVC: UIViewController?

  var presenter: AnalyticsViewToPresenterProtocol?
  var analyticsTableManager: AnalyticsTableManager?
  
  override func viewWillAppearAtFirstTime() {
    presenter?.onViewFirstWillAppear()
    observeCalendarChanging()
  }
    
  override func systemChangedCalendarDay() {
    DispatchQueue.main.async { [weak self] in
      self?.presenter?.onViewEvent(.onDayChanged)
    }
  }
}


extension AnalyticsViewController: AnalyticsPresenterToViewProtocol {
  func setupInitialState() {
    setupGlucoseBarsChart()
    setupGlucosePointsChart()
    
    mainView.days = Period.allCases.map { $0.amountOfDays }
    analyticsTableManager = AnalyticsTableManager(tableView: mainView.tableView)
    configureActions()
  }
  
  func updateAnalytics(_ analyticsDataViewItem: AnalyticsDataViewItem) {
    let analyticsCellTypeBuilder: AnalyticsCellTypeBuilderProtocol = AnalyticsCellTypeBuilder(with: analyticsDataViewItem)
    guard
      let barsChartView = glucoseBarsChartVC?.view,
      let pointsChartView = glucosePointsChartVC?.view else {
        return
    }
    
    if analyticsDataViewItem.isPointsChartHidden {
      analyticsTableManager?.cells = [.barsChart(barsChartView),
                                      .cards(analyticsCellTypeBuilder.glucoseCards()),
                                      .events(analyticsCellTypeBuilder.averageEvents())]
    } else {
      analyticsTableManager?.cells = [.barsChart(barsChartView),
                                      .cards(analyticsCellTypeBuilder.glucoseCards()),
                                      .pointsChart(pointsChartView),
                                      .events(analyticsCellTypeBuilder.averageEvents())]
    }
  }
}


private extension AnalyticsViewController {
  func configureActions() {
    mainView.tabMenu.didMenuChangeValue = { [unowned self] value in
      self.presenter?.onViewEvent(.onPeriodChanged(Period.get(value)))
    }
    mainView.buttonRightNavigation.addAction(for: .touchUpInside) { [unowned self] in
      self.presenter?.onViewEvent(.onButtonRightNavigationTap)
    }
  }
  
  func setupGlucosePointsChart() {
    if let childVC = glucosePointsChartVC {
      addChild(childVC)
      childVC.didMove(toParent: self)
    }
  }
  
  func setupGlucoseBarsChart() {
    if let childVC = glucoseBarsChartVC {
      addChild(childVC)
      childVC.didMove(toParent: self)
    }
  }
}
