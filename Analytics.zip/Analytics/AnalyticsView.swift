import UIKit

class AnalyticsView: BaseInteractiveView {
  private let navigationBar = UINavigationBar()
  private let title = UILabel()
  private let tabMenuContainer = UIView()
  let buttonRightNavigation = BaseButton()
  var tabMenu = TabsMenuView(with: [])
  let tableView = UITableView()
  
  var days: [Int] = [] {
    didSet {
      tabMenu.removeFromSuperview()
      tabMenu = TabsMenuView(with: days)
      tabMenuContainer.addSubview(tabMenu)
      tabMenu.fillSuperview()
    }
  }
  
  override func addViews() {
    [navigationBar, title, tabMenuContainer, tableView].forEach{
      addSubview($0)
    } 
  }
  
  override func anchorViews() {
    navigationBar
      .anchorTop(safeAreaLayoutGuideAnyIOS.topAnchor, statusBarOffset)
      .anchorLeft(leftAnchor, 0)
      .anchorRight(rightAnchor, 0)
      .anchorHeight(44)
    
    title
      .anchorTop(navigationBar.bottomAnchor, 0)
      .anchorLeft(leftAnchor, 16)
      .anchorRight(rightAnchor, 16)
    
    tabMenuContainer
      .anchorTop(title.bottomAnchor, 16)
      .anchorLeft(leftAnchor, 0)
      .anchorRight(rightAnchor, 0)
      .anchorHeight(44)
    
    tableView
      .anchorTop(tabMenuContainer.bottomAnchor, 0)
      .anchorLeft(leftAnchor, 0)
      .anchorRight(rightAnchor, 0)
      .anchorBottom(bottomAnchor, 0)
    
    if days.count > 0 {
      tabMenuContainer.addSubview(tabMenu)
      tabMenu.fillSuperview()
    }
    
  }
  
  override func configureViews() {
    backgroundColor = .white
    
    navigationBar.shadowImage = UIImage()
    navigationBar.setBackgroundImage(UIImage(), for: .default)
    navigationBar.backgroundColor = .clear
    navigationBar.isTranslucent = true
    navigationBar.barTintColor = .clear
    
    buttonRightNavigation.setTitle(LS.Analytics.Button.report, for: .normal)
    buttonRightNavigation.setTitleColor(UIColor.shadeBlack1, for: .normal)
    buttonRightNavigation.titleLabel?.font = UIFont.buttonsToolbar
    
    let rightNavigationItem = UIBarButtonItem(customView: buttonRightNavigation)
    
    let navigationItem = UINavigationItem()
    navigationItem.rightBarButtonItem = rightNavigationItem
    
    navigationBar.items = [navigationItem]
    buttonRightNavigation.sizeToFit()
    
    title.font = .headline1
    title.textColor = .blackBlue
    title.text = LS.MainTabBar.Tab.statTitle
    
    tableView.tableFooterView = UIView(frame: .zero)
    tableView.backgroundColor = .paleGrey
    tableView.estimatedRowHeight = 136
    tableView.rowHeight = UITableView.automaticDimension
    tableView.registerClass(GlucoseCardsCell.self)
    tableView.registerClass(AnalyticsOtherCell.self)
    tableView.registerClass(ExternalModuleCell.self)
    tableView.separatorInset = .zero
    tableView.allowsSelection = false
    tableView.showsVerticalScrollIndicator = false
    tableView.showsHorizontalScrollIndicator = false
  }
}

