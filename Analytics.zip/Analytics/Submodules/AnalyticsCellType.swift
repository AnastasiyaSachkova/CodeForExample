import UIKit

enum AnalyticsCellType {
  typealias Gradient = (left: UIColor, right: UIColor)
  
  case barsChart(UIView)
  case pointsChart(UIView)
  case cards([GlucoseCardType])
  case events([Event])
  case event(Event)
  
  enum Event {
    case other(imageName: String?, title: String?, descriptionText: NSAttributedString?)
  }
  
  enum GlucoseCardType {
    case average(value: Double, units: String, desc: String, gradient: Gradient)
    case measurements(value: Int, units: String, desc: String, gradient: Gradient)
  }
}

