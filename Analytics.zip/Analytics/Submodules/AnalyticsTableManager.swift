import UIKit

final class AnalyticsTableManager: NSObject {
  var eventHandler: EventHandler<ProfileTableManagerEvent>?
  private let tableView: UITableView
  private var modifiedCells: [AnalyticsCellType] = []
  
  var cells: [AnalyticsCellType] = [] {
    didSet {
      modifiedCells = AnalyticsCellTypeBuilder.modify(cells: cells)
      tableView.reloadData()
    }
  }
  
  init(tableView: UITableView) {
    self.tableView = tableView
    super.init()
    self.tableView.dataSource = self
    self.tableView.delegate = self
  }
  
  @objc func injected() {
    tableView.reloadData()
  }
}

extension AnalyticsTableManager: UITableViewDelegate, UITableViewDataSource {
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    let cellType = modifiedCells[indexPath.row]
    switch cellType {
    case .cards:
      return 136
    case .barsChart:
      return 290
    case .pointsChart:
      return 276
    default:
      return UITableView.automaticDimension
    }
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return modifiedCells.count
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cellType = modifiedCells[indexPath.row]
    switch cellType {
    case .barsChart(let view):
      let cell: ExternalModuleCell = tableView.dequeueReusableCell(forIndexPath: indexPath)
      cell.selectionStyle = .none
      cell.configure(with: view, moduleType: .barsChart)
      return cell
    case .cards(let cards):
      let cell: GlucoseCardsCell = tableView.dequeueReusableCell(forIndexPath: indexPath)
      cell.selectionStyle = .none
      cell.configure(with: cards)
      return cell
    case .pointsChart(let view):
      let cell: ExternalModuleCell = tableView.dequeueReusableCell(forIndexPath: indexPath)
      cell.selectionStyle = .none
      cell.configure(with: view, moduleType: .pointsChart)
      return cell
    case .event(let event):
      let cell: AnalyticsOtherCell = tableView.dequeueReusableCell(forIndexPath: indexPath)
      switch event {
      case let .other(imageName, title, descriptionText):
        cell.configure(image: UIImage(named: imageName ?? ""),
                       title: title,
                       descriptionText: descriptionText)
      }
      return cell
    case .events(_):
      return UITableViewCell()
    }
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    guard let cell = tableView.cellForRow(at: indexPath) as? ProfileSelectionCell else { return }
    eventHandler?(.onRowCellTap(cell.rowType))
  }
}
