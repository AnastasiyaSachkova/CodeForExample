import UIKit

final class TabsMenuView: BaseInteractiveView {
  typealias didMenuChangeValueClosure = (Int) -> Void
  
  private var stackView = UIStackView()
  private var borderLine = UIView()
  private var bottomLine = UIView()

  private var items: [String] = []
  private let itemSuffix = LS.Analytics.TabMenu.days
  private let offset: CGFloat = 18.0
  private var selectedIndex = 0
  
  var didMenuChangeValue: didMenuChangeValueClosure?
  
  private var bottomLineLeftConstraint: NSLayoutConstraint?
  
  init(with items: [Int]) {
    self.items = items.map { String($0) }
    super.init(frame: .zero)
  }
  
  override func addViews() {
    [stackView, borderLine, bottomLine].forEach {
      addSubview($0)
    }
  }
  
  override func anchorViews() {
    stackView
      .anchorLeft(leftAnchor, offset)
      .anchorRight(rightAnchor, offset)
      .anchorTop(topAnchor, 0)
      .anchorBottom(bottomAnchor, 0)
    
    bottomLine
      .anchorLeft(leftAnchor, 0)
      .anchorRight(rightAnchor, 0)
      .anchorBottom(bottomAnchor, 0)
      .anchorHeight(0.5)
    
    borderLine
      .anchorBottom(stackView.bottomAnchor, -3)
      .anchorHeight(6)
    
    borderLine.widthAnchor.constraint(equalTo: stackView.widthAnchor, multiplier: 1 / CGFloat(items.count > 0 ? items.count : 1)).isActive = true
    bottomLineLeftConstraint = borderLine._anchorLeft(stackView.leftAnchor, 0)
  }
  
  override func configureViews() {
    backgroundColor = .white
    stackView.axis = .horizontal
    stackView.alignment = .fill
    stackView.distribution = .fillEqually
    stackView.spacing = 0
    
    bottomLine.backgroundColor = .shadeBlack2
    borderLine.backgroundColor = .gOrangeB
    borderLine.layer.cornerRadius = 3
    
    setupButtons()
  }
}

private extension TabsMenuView {
  func setupButtons() {
    selectedIndex = 0
    for index in 0..<items.count {
      let menuButton = UILabel()
      menuButton.tag = index + 1
      let tapGesture = UITapGestureRecognizer(target: self, action: #selector(selectedMenuItem(_:)))
      menuButton.addGestureRecognizer(tapGesture)
      menuButton.isUserInteractionEnabled = true
      menuButton.text = "\(items[index]) \(itemSuffix)"
      menuButton.textColor = UIColor.blackBlue
      menuButton.textAlignment = .center
      menuButton.font = UIFont.body2
      menuButton.alpha = index == selectedIndex ? 1 : 0.6
      stackView.addArrangedSubview(menuButton)
    }
  }
  
  @objc func selectedMenuItem(_ sender: UITapGestureRecognizer) {
    guard let tag = sender.view?.tag else { return }
    updateMenu(forSelectedMenuItemWithTag: tag)
  }
  
  func updateMenu(forSelectedMenuItemWithTag index: Int) {
    guard
      let menuButton = stackView.viewWithTag(index) as? UILabel,
      let value = Int(items[index - 1]),
      selectedIndex != index - 1 else { return }
    
    bottomLineLeftConstraint?.constant = menuButton.frame.minX
    
    UIView.animate(withDuration: 0.2, delay: 0.0, options: [.curveEaseInOut], animations: {
      for subview in self.stackView.arrangedSubviews {
        if let subview = subview as? UILabel {
          subview.alpha = subview === menuButton ? 1 : 0.6
        }
      }
      self.layoutIfNeeded()
    })
    
    selectedIndex = index - 1
    didMenuChangeValue?(value)
  }
}

