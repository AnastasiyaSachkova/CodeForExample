import UIKit

class GlucoseCardsView: BaseInteractiveView {
  let collectionView: UICollectionView = {
    let layout = UICollectionViewFlowLayout()
    layout.minimumInteritemSpacing = 8
    layout.minimumLineSpacing = 8
    layout.scrollDirection = .horizontal
    layout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
    
    let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
    return collectionView
  }()
  
  override func addViews() {
    [collectionView].forEach {
      addSubview($0)
    }
  }
  
  override func anchorViews() {
    collectionView
      .anchorTop(topAnchor, 0)
      .anchorBottom(bottomAnchor, 0)
      .anchorLeft(leftAnchor, 0)
      .anchorRight(rightAnchor, 0)
  }
  
  override func configureViews() {
    backgroundColor = .paleGrey
    
    collectionView.backgroundColor = .clear
    collectionView.registerClass(GlucoseCardCell.self)
    collectionView.delaysContentTouches = false
    collectionView.showsHorizontalScrollIndicator = false
    collectionView.showsVerticalScrollIndicator = false
  }

}
