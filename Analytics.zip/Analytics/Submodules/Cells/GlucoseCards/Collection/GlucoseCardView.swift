import UIKit

class GlucoseCardView: BaseInteractiveView {
    private let gradientView = GradientView()
    private let numberLabel = UILabel()
    private let unitDescriptionLabel = UILabel()
    private let mainDescriptionLabel = UILabel()
    
    var intValue: Int? {
        get { return Int(numberLabel.text ?? "0") }
        set { numberLabel.text = String(newValue ?? 0) }
    }
    
    var doubleValue: Double? {
        get { return Double(numberLabel.text ?? "0.0") }
        set { numberLabel.text = String(format: "%.1f", newValue ?? 0.0).replacingOccurrences(of: ".", with: ",") }
    }
    
    var unit: String? {
        get { return unitDescriptionLabel.text }
        set { unitDescriptionLabel.text = newValue }
    }
    
    var desc: String? {
        get { return mainDescriptionLabel.text }
        set { mainDescriptionLabel.text = newValue }
    }
    
    var gradient = (left: UIColor.gGreenA, right: UIColor.gGreenA) {
        didSet {
            gradientView.gradientType = .topLeftBottomRight(left: gradient.left, right: gradient.right)
        }
    }
    
    override func addViews() {
        [gradientView, numberLabel, unitDescriptionLabel, mainDescriptionLabel].forEach {
            addSubview($0)
        }
    }
    
    override func anchorViews() {
        gradientView.fillSuperview()
        
        numberLabel
            .anchorLeft(leftAnchor, 16)
            .anchorTop(topAnchor, 12)
        
        unitDescriptionLabel
            .anchorLeft(numberLabel.rightAnchor, 7)
            .anchorRight(rightAnchor, 16, relation: .lessThanOrEqual)
            .anchorBottom(numberLabel.bottomAnchor, 7)
        
        mainDescriptionLabel
            .anchorLeft(leftAnchor, 16)
            .anchorRight(rightAnchor, 16)
            .anchorTop(numberLabel.bottomAnchor, 0)
            .anchorBottom(bottomAnchor, 24)
    }
    
    override func configureViews() {
        backgroundColor = .white
        layer.cornerRadius = 8
        clipsToBounds = true
        
        gradientView.backgroundColor = .white
        
        numberLabel.textColor = .white
        numberLabel.font = .weightG
        
        unitDescriptionLabel.textColor = .white
        unitDescriptionLabel.font = .title3
        unitDescriptionLabel.numberOfLines = 1
        
        mainDescriptionLabel.textColor = .white
        mainDescriptionLabel.font = .caption1
        mainDescriptionLabel.numberOfLines = 1
    }
}
