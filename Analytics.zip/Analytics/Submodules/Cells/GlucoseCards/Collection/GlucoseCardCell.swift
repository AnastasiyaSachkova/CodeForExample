import UIKit

class GlucoseCardCell: BaseCollectionViewCell<GlucoseCardView> {
  func configure(with card: AnalyticsCellType.GlucoseCardType) {
    switch card {
    case .average(let value, let unit, let desc, let gradient):
      mainView.doubleValue = value
      mainView.unit = unit
      mainView.desc = desc
      mainView.gradient = gradient
    case .measurements(let value, let unit, let desc, let gradient):
      mainView.intValue = value
      mainView.unit = unit
      mainView.desc = desc
      mainView.gradient = gradient
    }
  }
}
