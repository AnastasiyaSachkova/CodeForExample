import UIKit

class GlucoseCardsCell: BaseTableViewCell<GlucoseCardsView> {
  let collectionManager = GlucoseCardsCollectionManager()
  
  func configure(with cards: [AnalyticsCellType.GlucoseCardType]) {
    collectionManager.cards = cards
    mainView.collectionView.delegate = collectionManager
    mainView.collectionView.dataSource = collectionManager
    mainView.collectionView.reloadData()
  }
}
