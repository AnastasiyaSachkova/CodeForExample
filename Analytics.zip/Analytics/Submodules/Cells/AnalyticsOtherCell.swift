import UIKit

class AnalyticsOtherCell: BaseTableViewCell<AnalyticsOtherView> {
  func configure(image: UIImage?, title: String?, descriptionText: NSAttributedString?) {
    mainView.icon = image
    mainView.title = title
    mainView.descriptionText = descriptionText
  }
}
