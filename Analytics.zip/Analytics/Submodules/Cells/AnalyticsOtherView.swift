import UIKit

class AnalyticsOtherView: BaseInteractiveView {
  private let iconImageView = UIImageView()
  private let stackView = UIStackView()
  private let titleLabel = UILabel()
  private let descriptionLabel = UILabel()
  
  var icon: UIImage? {
    get { return iconImageView.image }
    set {
      iconImageView.isHidden = newValue == nil
      iconImageView.image = newValue
    }
  }
  
  var title: String? {
    get { return titleLabel.text }
    set { titleLabel.text = newValue }
  }
  
  var descriptionText: NSAttributedString? {
    get { return descriptionLabel.attributedText }
    set { descriptionLabel.attributedText = newValue }
  }
  
  override func addViews() {
    [iconImageView, stackView].forEach {
      addSubview($0)
    }
    
    [titleLabel, descriptionLabel].forEach {
      stackView.addArrangedSubview($0)
    }
  }
  
  override func anchorViews() {
    iconImageView
      .anchorTop(topAnchor, 17)
      .anchorLeft(leftAnchor, 16)
      .anchorWidth(32)
      .anchorHeight(32)
    stackView
      .anchorLeft(iconImageView.rightAnchor, 12)
      .anchorRight(rightAnchor, 16)
      .anchorTop(topAnchor, 16)
      .anchorBottom(bottomAnchor, 16)
  }
  
  override func configureViews() {
    backgroundColor = .white
    
    stackView.axis = .vertical
    stackView.alignment = .fill
    stackView.distribution = .fill
    stackView.spacing = 4
    
    titleLabel.textColor = .blackBlue
    titleLabel.font = UIFont.body2
    
    descriptionLabel.textColor = .shadeBlack0
    descriptionLabel.font = UIFont.caption1
    descriptionLabel.numberOfLines = 0
    
    iconImageView.contentMode = .scaleAspectFit
    iconImageView.setContentCompressionResistancePriority(UILayoutPriority(751), for: .horizontal)
    iconImageView.setContentHuggingPriority(UILayoutPriority(251), for: .horizontal)
  }
}
