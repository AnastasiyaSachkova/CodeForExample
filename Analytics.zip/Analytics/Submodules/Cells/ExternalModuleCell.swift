import UIKit

enum ExternalModuleType {
  case barsChart
  case pointsChart
}

final class ExternalModuleCell: BaseTableViewCell<UIView> {
  private var type: ExternalModuleType?

  private var hostedView: UIView? {
    didSet {
      guard let hostedView = hostedView, let type = type else {
        return
      }
      
      hostedView.backgroundColor = .white
      hostedView.clipsToBounds = true
      
      contentView.addSubview(hostedView)
      
      switch type {
      case .barsChart:
        hostedView.fillSuperview()
        hostedView.border(.notSpecified, cornerRadius: 0)
      case .pointsChart:
        hostedView
          .anchorTop(mainView.topAnchor, 0)
          .anchorBottom(mainView.bottomAnchor, 16)
          .anchorLeft(mainView.leftAnchor, 0)
          .anchorRight(mainView.rightAnchor, 0)
        
        hostedView.border(.shadeBlack1pt, cornerRadius: 8)
      }
    }
  }
  
  override func prepareForReuse() {
    super.prepareForReuse()
    
    if hostedView?.superview == mainView { //Make sure that hostedView hasn't been added as a subview to a different cell
      hostedView?.removeFromSuperview()
    }
    
    hostedView = nil
  }
  
  func configure(with view: UIView?, moduleType: ExternalModuleType) {
    type = moduleType
    hostedView = view
    backgroundColor = .clear
    contentView.backgroundColor = .clear
    mainView.backgroundColor = .clear
  }
}
