import UIKit

protocol AnalyticsCellTypeBuilderProtocol {
  func glucoseCards() -> [AnalyticsCellType.GlucoseCardType]
  func averageEvents() -> [AnalyticsCellType.Event]
}

class AnalyticsCellTypeBuilder: AnalyticsCellTypeBuilderProtocol {
  private var analyticsDataViewItem: AnalyticsDataViewItem
  
  init(with analyticsDataViewItem: AnalyticsDataViewItem) {
    self.analyticsDataViewItem = analyticsDataViewItem
  }

  func glucoseCards() -> [AnalyticsCellType.GlucoseCardType] {
    var averageGradient = (left: UIColor.gGreenA, right: UIColor.gGreenB)
    if analyticsDataViewItem.average > analyticsDataViewItem.maxGlucoseValue {
      averageGradient = (left: .gOrangeA, right: .gOrangeB)
    }
    if analyticsDataViewItem.average < analyticsDataViewItem.minGlucoseValue {
      averageGradient = (left: .gPurpurA, right: .gPurpurB)
    }
    if analyticsDataViewItem.average == 0 {
      averageGradient = (left: .blackBlue, right: .blackBlue)
    }
    return [
      .average(value: analyticsDataViewItem.average,
               units: LS.Analytics.Cards.AnalyticsCellType.AverageLevel.unit,
               desc: LS.Analytics.Cards.AnalyticsCellType.AverageLevel.description,
               gradient: averageGradient),
      .measurements(value: analyticsDataViewItem.measurementCount,
                    units: analyticsDataViewItem.isPeriod ? LS.Analytics.Cards.AnalyticsCellType.Measurements.Count.unitPeriod : LS.Analytics.Cards.AnalyticsCellType.Measurements.Count.unitDay,
                    desc: LS.Analytics.Cards.AnalyticsCellType.Measurements.Count.description,
                    gradient: (left: .blackBlue, right: .blackBlue)),
      .measurements(value: analyticsDataViewItem.measurementsHigh.count,
                    units: "(\(analyticsDataViewItem.measurementsHigh.percent)% \(LS.Analytics.Cards.AnalyticsCellType.Measurements.unit))",
                    desc: LS.Analytics.Cards.AnalyticsCellType.Measurements.High.description,
                    gradient: (left: .gOrangeA, right: .gOrangeB)),
      .measurements(value: analyticsDataViewItem.measurementsNormal.count,
                    units: "(\(analyticsDataViewItem.measurementsNormal.percent)% \(LS.Analytics.Cards.AnalyticsCellType.Measurements.unit))",
                    desc: LS.Analytics.Cards.AnalyticsCellType.Measurements.Normal.description,
                    gradient: (left: .gGreenA, right: .gGreenB)),
      .measurements(value: analyticsDataViewItem.measurementsLow.count,
                    units: "(\(analyticsDataViewItem.measurementsLow.percent)% \(LS.Analytics.Cards.AnalyticsCellType.Measurements.unit))",
                    desc: LS.Analytics.Cards.AnalyticsCellType.Measurements.Low.description,
                    gradient: (left: .gPurpurA, right: .gPurpurB))
    ]
  }
  
  func averageEvents() -> [AnalyticsCellType.Event] {
    var cells: [AnalyticsCellType.Event] = [
      .other(imageName: "ic_xe_h",
             title: LS.Analytics.AverageEvents.Bread.title,
             descriptionText: NSMutableAttributedString(string: analyticsDataViewItem.isPeriod ?
                LS.Analytics.AverageEvents.Bread.descriptionPeriod :
                LS.Analytics.AverageEvents.Bread.descriptionDay)
                .medium(" \(String(format: "%.1f", analyticsDataViewItem.bread).replacingOccurrences(of: ".", with: ",")) \(analyticsDataViewItem.isPeriod ? LS.Event.Units.breadPeriod : LS.Event.Units.breadDay).")),
      .other(imageName: "ic_insulin_h",
             title: LS.Analytics.AverageEvents.Insulin.title,
             descriptionText: NSMutableAttributedString(string: String(format: analyticsDataViewItem.isPeriod ?
                LS.Analytics.AverageEvents.Insulin.descriptionPeriod :
                LS.Analytics.AverageEvents.Insulin.descriptionDay,
                        analyticsDataViewItem.allInsulinTypes))
              .medium(" \(String(format: "%.1f", analyticsDataViewItem.insulin).replacingOccurrences(of: ".", with: ",")) \(LS.Event.Units.units).")),
      .other(imageName: "ic_insulin_h",
             title: LS.Analytics.AverageEvents.BolusInsulin.title,
             descriptionText: NSMutableAttributedString(string: String(format: analyticsDataViewItem.isPeriod ?
                LS.Analytics.AverageEvents.BolusInsulin.descriptionPeriod :
                LS.Analytics.AverageEvents.BolusInsulin.descriptionDay,             analyticsDataViewItem.bolusInsulinString))
              .medium(" \(String(format: "%.1f", analyticsDataViewItem.boluseInsulin).replacingOccurrences(of: ".", with: ",")) \(LS.Event.Units.units).")),
      .other(imageName: "ic_insulin_h",
             title: LS.Analytics.AverageEvents.BasalInsulin.title,
             descriptionText: NSMutableAttributedString(string: String(format: analyticsDataViewItem.isPeriod ?
                LS.Analytics.AverageEvents.BasalInsulin.descriptionPeriod :
                LS.Analytics.AverageEvents.BasalInsulin.descriptionDay, analyticsDataViewItem.basalInsulinString))
              .medium(" \(String(format: "%.1f", analyticsDataViewItem.basalInsulin).replacingOccurrences(of: ".", with: ",")) \(LS.Event.Units.units).")),
      .other(imageName: "ic_active_h",
             title: LS.Analytics.AverageEvents.Active.title,
             descriptionText:
        NSMutableAttributedString(string:
          String(format:analyticsDataViewItem.isPeriod ? LS.Analytics.AverageEvents.Active.titlePeriod : LS.Analytics.AverageEvents.Active.titleDay, analyticsDataViewItem.active.count) + "\n" +
            String(format:analyticsDataViewItem.isPeriod ? LS.Analytics.AverageEvents.Active.descriptionPeriod : LS.Analytics.AverageEvents.Active.descriptionDay))
          .medium(" \(analyticsDataViewItem.active.minute) \(LS.Event.Units.minutes)."))
    ]
      
    if analyticsDataViewItem.isBreadUnitsHidden {
        cells.removeFirst()
    }
      
    return  cells
  }
}

extension AnalyticsCellTypeBuilder {
  static func modify(cells: [AnalyticsCellType]) -> [AnalyticsCellType] {
    var c: [AnalyticsCellType] = []
    cells.forEach {
      if case AnalyticsCellType.events(let events) = $0 {
        events.forEach {
          switch $0 {
          case .other(let i, let t, let d):
            c.append(AnalyticsCellType.event(.other(imageName: i, title: t, descriptionText: d)))
          }
        }
      } else {
        c.append($0)
      }
    }
    return c
  }
}
