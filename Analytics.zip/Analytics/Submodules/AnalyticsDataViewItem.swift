import Foundation

struct AnalyticsDataViewItem {
    typealias MeasuremenValue = (count: Int, percent: Int)
    typealias ActiveValue = (count: Int, minute: Int)
    
    var isPointsChartHidden: Bool = true
    var isBreadUnitsHidden: Bool = false
    var isPeriod: Bool = false
    var average: Double = 0.0
    var measurementCount: Int = 0
    var measurementsHigh: MeasuremenValue = (count: 0, percent: 0)
    var measurementsNormal: MeasuremenValue = (count: 0, percent: 0)
    var measurementsLow: MeasuremenValue = (count: 0, percent: 0)
    var bread: Double = 0.0
    var insulin: Double = 0.0
    var basalInsulin: Double = 0.0
    var boluseInsulin: Double = 0.0
    var active: ActiveValue = (count: 0, minute: 0)
    
    var minGlucoseValue = 0.0
    var maxGlucoseValue = 0.0
    
    var bolusInsulinString: String = ""
    var basalInsulinString: String = ""
    var allInsulinTypes: String = ""
    
    init(period: Period, events: [EventEntity], profileSettings: ProfileSettingsEntity, insulinStaticTypes: [InsulinStaticticType], insulinTypes: [InsulinType]) {
        
        var glucoseCount = 0
        var glucoseAllValues: Double = 0.0
        
        var measurementsLowCount = 0
        var measurementsLowValue = 0.0
        var measurementsNormalCount = 0
        var measurementsNormalValue = 0.0
        var measurementsHighCount = 0
        var measurementsHighValue = 0.0
        
        var breadValue = 0.0
        var breadLastDate: Date?
        var breadDayCount = 0
        
        var insulinValue = 0.0
        var insulinDayCount = 0
        var insulinLastDate: Date?
        
        var basalInsulinValue = 0.0
        var basalInsulinDayCount = 0
        var basalInsulinLastDate: Date?
        
        var bolusInsulinValue = 0.0
        var bolusInsulinDayCount = 0
        var bolusInsulinLastDate: Date?
        
        var activityCount = 0
        var activityValue = 0
        
        if case Period.day(_) = period { isPeriod = false }
        else { isPeriod = true }
        
        isBreadUnitsHidden = profileSettings.diabetType == .secondTablets
        
        let minGlucoseLevel = profileSettings.glucoseLevelsAverage?.min ?? 0.0
        let maxGlucoseLevel = profileSettings.glucoseLevelsAverage?.max ?? 0.0
        
        let basalStatisticType = insulinStaticTypes.first { $0.name == "basalInsulinTypes" }
        let bolusStatisticType = insulinStaticTypes.first { $0.name == "bolusInsulinTypes" }
        
        bolusInsulinString = insulinTypes.filter({ type in
            bolusStatisticType?.ownedTypes.contains(type.code) ?? false
        }).map({ $0.name.lowercased() }).joined(separator: "+")
        
        basalInsulinString = insulinTypes.filter({ type in
            basalStatisticType?.ownedTypes.contains(type.code) ?? false
        }).map({ $0.name.lowercased() }).joined(separator: "+")

        if !basalInsulinString.isEmpty && !bolusInsulinString.isEmpty {
            allInsulinTypes = [basalInsulinString, bolusInsulinString].joinedWithBrackets()
        }
        
        if !basalInsulinString.isEmpty {
            self.basalInsulinString = [basalInsulinString].joinedWithBrackets()
        }
        if !bolusInsulinString.isEmpty {
            self.bolusInsulinString = [bolusInsulinString].joinedWithBrackets()
        }
        
        let sortedEvents = events.sorted { $0.date < $1.date }
        sortedEvents.forEach {
            if $0.data?.eventType == .insulin {
                measurementCount += 1
            }
            if $0.data?.eventType == .glucose {
                let glucoseValue = $0.data?.value.value ?? 0.0
                glucoseCount += 1
                glucoseAllValues += glucoseValue
                
                if glucoseValue > maxGlucoseLevel {
                    measurementsHighCount += 1
                    measurementsHighValue += glucoseValue
                } else if glucoseValue < minGlucoseLevel {
                    measurementsLowCount += 1
                    measurementsLowValue += glucoseValue
                } else {
                    measurementsNormalCount += 1
                    measurementsNormalValue += glucoseValue
                }
            }
            if $0.data?.eventType == .bread {
                if $0.date.dayOfYear != breadLastDate?.dayOfYear {
                    breadDayCount += 1
                    breadLastDate = $0.date
                }
                breadValue += $0.data?.value.value ?? 0.0
            }
            if $0.data?.eventType == .activity {
                activityCount += 1
                activityValue += ($0.data?.activityDuration.value ?? 0) / 60
            }
            if $0.data?.eventType == .insulin {
                guard let insulinCode = $0.data?.insulinCode, let basalStatisticType, let bolusStatisticType else { return }
                
                   
                if basalStatisticType.ownedTypes.contains(insulinCode) {
                    if $0.date.dayOfYear != basalInsulinLastDate?.dayOfYear {
                        basalInsulinDayCount += 1
                        basalInsulinLastDate = $0.date
                    }
                    basalInsulinValue += $0.data?.value.value ?? 0.0
                }
                
                if bolusStatisticType.ownedTypes.contains(insulinCode) {
                    if $0.date.dayOfYear != bolusInsulinLastDate?.dayOfYear {
                        bolusInsulinDayCount += 1
                        bolusInsulinLastDate = $0.date
                    }
                    bolusInsulinValue += $0.data?.value.value ?? 0.0
                }
                if basalStatisticType.ownedTypes.contains(insulinCode) || bolusStatisticType.ownedTypes.contains(insulinCode) {
                    if $0.date.dayOfYear != insulinLastDate?.dayOfYear {
                        insulinDayCount += 1
                        insulinLastDate = $0.date
                    }
                    insulinValue += $0.data?.value.value ?? 0.0
                }
            }
        }
        
        measurementCount = glucoseCount
        isPointsChartHidden = !(!isPeriod && measurementCount > 0)
        
        average = glucoseAllValues / (glucoseCount != 0 ? Double(glucoseCount) : 1.0)
        minGlucoseValue = minGlucoseLevel
        maxGlucoseValue = maxGlucoseLevel
        
        if glucoseCount > 0 {
            average = glucoseAllValues / Double(glucoseCount)
            measurementsHigh = (count: measurementsHighCount,
                                percent: Int(((Double(measurementsHighCount) / Double(glucoseCount)) * 100).rounded(.toNearestOrAwayFromZero)))
            measurementsNormal = (count: measurementsNormalCount,
                                  percent:  Int(((Double(measurementsNormalCount) / Double(glucoseCount)) * 100).rounded(.toNearestOrAwayFromZero)))
            measurementsLow = (count: measurementsLowCount,
                               percent:  Int(((Double(measurementsLowCount) / Double(glucoseCount)) * 100).rounded(.toNearestOrAwayFromZero)))
        } else {
            average = 0
            measurementsHigh = (count: 0, percent: 0)
            measurementsNormal = (count: 0, percent: 0)
            measurementsLow = (count: 0, percent: 0)
        }
        
        if period.amountOfDays > 0 && breadValue > 0 {
            bread = breadValue / Double(breadDayCount)
        } else {
            bread = 0.0
        }
        
        if period.amountOfDays > 0 && bolusInsulinValue > 0 {
            boluseInsulin = bolusInsulinValue / Double(bolusInsulinDayCount)
        } else {
            boluseInsulin = 0.0
        }
        
        if period.amountOfDays > 0 && basalInsulinValue > 0 {
            basalInsulin = basalInsulinValue / Double(basalInsulinDayCount)
        } else {
            basalInsulin = 0.0
        }
        
        if period.amountOfDays > 0 && insulinValue > 0 {
            insulin = insulinValue / Double(insulinDayCount)
        } else {
            insulin = 0.0
        }
        
        if activityCount > 0 {
            active = (count: activityCount, minute: activityValue / activityCount)
        } else {
            active = (count: 0, minute: 0)
        }
    }
}

extension Array where Element == String {
  func joinedWithBrackets() -> String {
      return " (" + self.joined(separator: "+") + ")"
  }
}
