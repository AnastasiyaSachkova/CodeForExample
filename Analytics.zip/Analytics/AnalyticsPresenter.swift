import Foundation

protocol AnalyticsViewToPresenterProtocol: AnyObject {
  func onViewFirstWillAppear()
  func onViewEvent(_ event: AnalyticsViewEvent)
}

protocol AnalyticsInteractorToPresenterProtocol: ErrorHandlable {
  func onInteractorSuccessEventsFetch(events: [EventEntity]?, forPeriod: Period, profileSettings: ProfileSettingsEntity?, statisticsTypes: [InsulinStaticticType], insulinTypes: [InsulinType])
}

protocol AnalyticsModuleOutput: AnyObject {
  
}

protocol AnalyticsModuleInput: AnyObject {
  
}


final class AnalyticsPresenter: AnalyticsModuleInput, AnalyticsModuleOutput, AnalitycsLoggable {
  weak var view: AnalyticsPresenterToViewProtocol?
  var interactor: AnalyticsPresenterToInteractorProtocol?
  var router: AnalyticsRouter.Routes?
  
  //Module input
  var glucosePointsModule: GlucosePointsModuleInput?
  var glucoseBarsModule: GlucoseBarsModuleInput?
}


extension AnalyticsPresenter: AnalyticsViewToPresenterProtocol {
  func onViewFirstWillAppear() {
    view?.setupInitialState()
    interactor?.loadEvents(with: .days7)
  }
  
  func onViewEvent(_ event: AnalyticsViewEvent) {
    switch event {
    case .onPeriodChanged(let period):
      interactor?.loadEvents(with: period)
      glucoseBarsModule?.period = period
      analyticsService?.log(.analyticsPeriodChanged(period: period))
    case .onButtonRightNavigationTap:
      router?.toReport()
    case .onDayChanged:
        guard let period = glucoseBarsModule?.period else { return }
        interactor?.loadEvents(with: period)
        glucoseBarsModule?.period = period
        glucosePointsModule?.date = Date()
    }
  }
}


extension AnalyticsPresenter: AnalyticsInteractorToPresenterProtocol {
  func onInteractorError(_ error: Error) {
    
  }
  
  func onInteractorSuccessEventsFetch(events: [EventEntity]?, forPeriod: Period, profileSettings: ProfileSettingsEntity?, statisticsTypes: [InsulinStaticticType], insulinTypes: [InsulinType]) {
    guard let events = events else { return }
    guard let profileSettings = profileSettings else { return }
      view?.updateAnalytics(AnalyticsDataViewItem(period: forPeriod, events: events, profileSettings: profileSettings, insulinStaticTypes: statisticsTypes, insulinTypes: insulinTypes))
  }
}

extension AnalyticsPresenter: GlucoseBarsModuleOutput {
  func onDaySelected(date: Date) {
    glucosePointsModule?.date = date
    interactor?.loadEvents(with: Period.day(date))
  }
  
  func onDayDeselected() {
    interactor?.loadEvents(with: nil)
  }
}
