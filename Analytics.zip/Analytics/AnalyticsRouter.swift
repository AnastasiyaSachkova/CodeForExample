import UIKit


final class AnalyticsRouter: BaseRouter, AnalyticsRouter.Routes {
  typealias Routes = ReportRoute
}
